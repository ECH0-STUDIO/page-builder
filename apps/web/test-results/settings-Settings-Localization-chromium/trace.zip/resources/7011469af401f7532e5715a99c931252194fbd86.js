(globalThis["TURBOPACK_CHUNK_LISTS"] || (globalThis["TURBOPACK_CHUNK_LISTS"] = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: ["static/chunks/apps_web_src_lib_image-utils_ts_0j~yfgi._.js","static/chunks/0fuv_@supabase_postgrest-js_dist_index_mjs_0d5s11t._.js","static/chunks/0fuv_@supabase_auth-js_dist_module_12aw5ob._.js","static/chunks/0fuv_tailwind-merge_dist_bundle-mjs_mjs_0ck9ch.._.js","static/chunks/0fuv_@supabase_01pxzar._.js","static/chunks/0fuv_@radix-ui_09wul15._.js","static/chunks/0fuv_@floating-ui_0j3g7-t._.js","static/chunks/0fuv_0cqw7bv._.js","static/chunks/apps_web_src_0kx~qny._.js"],
    source: "dynamic"
});
