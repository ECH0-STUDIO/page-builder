(globalThis["TURBOPACK"] || (globalThis["TURBOPACK"] = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/apps/web/src/i18n/dictionaries/en.json.[json].cjs [app-client] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "static/chunks/apps_web_src_i18n_dictionaries_en_json_[json]_cjs_10s71ko._.js",
  "static/chunks/apps_web_src_i18n_dictionaries_en_json_[json]_cjs_13yce1t._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/apps/web/src/i18n/dictionaries/en.json.[json].cjs [app-client] (ecmascript)");
    });
});
}),
"[project]/apps/web/src/i18n/dictionaries/vi.json.[json].cjs [app-client] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "static/chunks/apps_web_src_i18n_dictionaries_vi_json_[json]_cjs_0y1j0w~._.js",
  "static/chunks/apps_web_src_i18n_dictionaries_vi_json_[json]_cjs_13yce1t._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/apps/web/src/i18n/dictionaries/vi.json.[json].cjs [app-client] (ecmascript)");
    });
});
}),
]);