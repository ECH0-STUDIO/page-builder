(globalThis["TURBOPACK_CHUNK_LISTS"] || (globalThis["TURBOPACK_CHUNK_LISTS"] = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: ["static/chunks/apps_web_src_i18n_dictionaries_vi_json_[json]_cjs_0y1j0w~._.js"],
    source: "dynamic"
});
