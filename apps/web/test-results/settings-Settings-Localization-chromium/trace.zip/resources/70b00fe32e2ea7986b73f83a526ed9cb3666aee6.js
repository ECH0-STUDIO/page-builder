(globalThis["TURBOPACK_CHUNK_LISTS"] || (globalThis["TURBOPACK_CHUNK_LISTS"] = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: ["static/chunks/[root-of-the-server]__11fq1tx._.css","static/chunks/0fuv_@tanstack_query-devtools_build_06y5s0w._.js","static/chunks/0fuv_0q0uc2v._.js","static/chunks/apps_web_src_0atl11~._.js"],
    source: "dynamic"
});
