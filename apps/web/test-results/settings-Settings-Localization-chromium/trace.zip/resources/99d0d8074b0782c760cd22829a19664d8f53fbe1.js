(globalThis["TURBOPACK_CHUNK_LISTS"] || (globalThis["TURBOPACK_CHUNK_LISTS"] = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: ["static/chunks/apps_web_src_i18n_dictionaries_0m2km1q._.js","static/chunks/apps_web_0icjc7_._.js"],
    source: "dynamic"
});
