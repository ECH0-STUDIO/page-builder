(globalThis["TURBOPACK_CHUNK_LISTS"] || (globalThis["TURBOPACK_CHUNK_LISTS"] = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: ["static/chunks/0fuv_@supabase_postgrest-js_dist_index_mjs_0d5s11t._.js","static/chunks/0fuv_@supabase_auth-js_dist_module_12aw5ob._.js","static/chunks/0fuv_tailwind-merge_dist_bundle-mjs_mjs_0ck9ch.._.js","static/chunks/0fuv_0~zgxwq._.js","static/chunks/apps_web_src_0l41-b2._.js"],
    source: "dynamic"
});
