(globalThis["TURBOPACK"] || (globalThis["TURBOPACK"] = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/apps/web/node_modules/@tanstack/query-devtools/build/DevtoolsComponent/VKXKX7EQ.js [app-client] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "static/chunks/0fuv_@tanstack_query-devtools_build_0n7ff~0._.js",
  "static/chunks/0fuv_@tanstack_query-devtools_build_DevtoolsComponent_VKXKX7EQ_0g7iiyu.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/apps/web/node_modules/@tanstack/query-devtools/build/DevtoolsComponent/VKXKX7EQ.js [app-client] (ecmascript)");
    });
});
}),
"[project]/apps/web/node_modules/@tanstack/query-devtools/build/DevtoolsPanelComponent/ZUJJ2RGI.js [app-client] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "static/chunks/0fuv_@tanstack_query-devtools_build_000q.vj._.js",
  "static/chunks/0fuv_@tanstack_query-devtools_build_DevtoolsPanelComponent_ZUJJ2RGI_0g7iiyu.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/apps/web/node_modules/@tanstack/query-devtools/build/DevtoolsPanelComponent/ZUJJ2RGI.js [app-client] (ecmascript)");
    });
});
}),
]);