(globalThis["TURBOPACK"] || (globalThis["TURBOPACK"] = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/apps/web/src/lib/image-utils.ts [app-client] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "static/chunks/apps_web_src_lib_image-utils_ts_0ay2w~m._.js",
  "static/chunks/apps_web_src_lib_image-utils_ts_0.ghxo-._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/apps/web/src/lib/image-utils.ts [app-client] (ecmascript)");
    });
});
}),
]);