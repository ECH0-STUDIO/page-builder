(globalThis["TURBOPACK_CHUNK_LISTS"] || (globalThis["TURBOPACK_CHUNK_LISTS"] = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: ["static/chunks/0fuv_@tanstack_query-devtools_build_0n7ff~0._.js"],
    source: "dynamic"
});
