(globalThis["TURBOPACK_CHUNK_LISTS"] || (globalThis["TURBOPACK_CHUNK_LISTS"] = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: ["static/chunks/apps_web_src_components_06-illd._.js","static/chunks/apps_web_src_0m.1n_u._.js","static/chunks/0fuv_07u-vqd._.js"],
    source: "dynamic"
});
