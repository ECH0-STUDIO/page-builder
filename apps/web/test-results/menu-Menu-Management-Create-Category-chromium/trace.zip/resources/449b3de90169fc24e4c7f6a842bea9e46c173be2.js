(globalThis["TURBOPACK"] || (globalThis["TURBOPACK"] = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/apps/web/node_modules/qrcode/lib/browser.js [app-client] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "static/chunks/0fuv_05jz3ey._.js",
  "static/chunks/0fuv_qrcode_lib_browser_05b5x~w.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/apps/web/node_modules/qrcode/lib/browser.js [app-client] (ecmascript)");
    });
});
}),
]);