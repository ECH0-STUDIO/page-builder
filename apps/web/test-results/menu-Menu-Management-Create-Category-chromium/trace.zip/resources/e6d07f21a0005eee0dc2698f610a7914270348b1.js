(globalThis["TURBOPACK_CHUNK_LISTS"] || (globalThis["TURBOPACK_CHUNK_LISTS"] = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: ["static/chunks/0fuv_qrcode_lib_browser_00kekc_.js","static/chunks/apps_web_src_134npuq._.js","static/chunks/0fuv_0rbxou~._.js"],
    source: "dynamic"
});
